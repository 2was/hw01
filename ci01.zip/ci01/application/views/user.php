<html lang="en">
<head>
   <meta charset="utf-8">
   <title></title>
   <style type="text/css">
   #body {
		margin: 0 15px 0 15px;
	}
	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}
	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	</style>
</head>
<body>

<div id="container">
<table style="width;80%">
  <tr>
   <th>id</th>
    <th>username</th>
     <th>email</th>
     </tr>

   <tr>
   <th>Bill Gates</th>
    <th>55577854</th>
     <th>55577854</th>
     </tr>

	<?php  

	  foreach ($rows as $row)
	  {
          echo '<tr>';
	  	  echo '<td>' .$row->id . '</td>';
	  	  echo '<td>' .$row->username . '</td>';
	  	  echo '<td>' .$row->email . '</td>';
          echo '<tr>';
	  }
?>
</table>
	
</div>

</body>
</html>

