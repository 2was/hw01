<?php echo $title;?>
<br>
<?php echo $banner;?>