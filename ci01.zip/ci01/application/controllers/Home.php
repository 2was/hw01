<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
		//echo 'Home Page';
		$data['title'] = 'home page';
		$data['banner'] = 'Home sweet page -- 2was';
		$this->load->view('Home', $data);
	}
	public function user()
	{

		//$data['title'] = 'user page';
		//$data['banner'] = 'show user';

		$this->load->model('Member');
		$rows= $this->Member->getAll();
        $data['rows'] = $rows ;
        // foreach ($rows as $row)
         //{
         	//echo $row->id; 
         	//$data['id']=$row->id;
         	//$data['username']=$row->username;
         	//echo $row->id;
         	//echo $row->username; echo '<br>';
         	//echo $row->email; echo'<br>';
         	//echo'<br>';
         	//$data[$row->id]['username'] = $row->username;
         
         $this->load->view('user', $data);
	}
}

