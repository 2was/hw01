<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Model {

	public function getAll()
	{
		//echo 'Home Page';
		$query = $this->db->query('SELECT id, username ,email FROM user');
		return $query->result();

	}

}
